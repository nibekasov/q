---
title: 'Machine Learning'

layout: nil
---

### Метрические алгоритмы

#### kNN

* Просто об [kNN](https://www.youtube.com/watch?v=4ObVzTuFivY)
* kNN за [5 минут](https://www.youtube.com/watch?v=MDniRwXizWo)

### Временные ряды

#### Расстояние между временными рядами

* [DTW](https://www.youtube.com/watch?v=tfOevFKQIjQ&t=327s)
